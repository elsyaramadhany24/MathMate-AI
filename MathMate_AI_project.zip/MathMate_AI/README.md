# MathMate AI

Chatbot pembelajaran matematika menggunakan Gemini API dan Streamlit. Aplikasi menerima pertanyaan teks serta unggahan gambar dan PDF, lalu meminta Gemini menyusun pembahasan matematika langkah demi langkah.

## Fitur

- Pertanyaan matematika dalam bahasa Indonesia.
- Input teks.
- Unggah gambar soal (PNG, JPG, JPEG, WEBP, HEIC, HEIF).
- Unggah PDF materi/soal.
- Riwayat percakapan singkat.
- Instruksi respons untuk menjelaskan konsep, rumus, langkah perhitungan, dan jawaban akhir.

## 1. Persiapan

Install Python 3.10 atau lebih baru, lalu unduh atau clone repositori ini.

Buka terminal pada folder proyek dan jalankan:

```bash
python -m venv .venv
```

Aktifkan environment:

**Windows Command Prompt**
```bat
.venv\Scripts\activate
```

**Windows PowerShell**
```powershell
.\.venv\Scripts\Activate.ps1
```

Install pustaka:
```bash
python -m pip install --upgrade pip
pip install -r requirements.txt
```

## 2. Dapatkan Gemini API key

1. Buka https://aistudio.google.com/apikey
2. Masuk menggunakan akun Google dan buat API key.
3. Simpan API key secara pribadi. Jangan menaruhnya di kode atau mengunggahnya ke GitHub.

Atur API key di Windows PowerShell untuk sesi terminal saat ini:

```powershell
$env:GEMINI_API_KEY="MASUKKAN_API_KEY_KAMU"
```

Atau di Command Prompt:

```bat
set GEMINI_API_KEY=MASUKKAN_API_KEY_KAMU
```

Untuk pengaturan permanen lokal, kamu juga bisa membuat folder `.streamlit` dan file `secrets.toml` berisi:

```toml
GEMINI_API_KEY = "MASUKKAN_API_KEY_KAMU"
```

Jangan pernah mengunggah `secrets.toml` ke GitHub. File tersebut sudah diabaikan oleh `.gitignore`.

## 3. Jalankan aplikasi

Dari folder proyek, jalankan:

```bash
streamlit run app.py
```

Browser biasanya akan terbuka otomatis. Jika tidak, buka alamat lokal yang ditampilkan di terminal, biasanya http://localhost:8501.

## 4. Uji chatbot

Coba pertanyaan seperti:
- `Selesaikan 2x + 5 = 17 dengan langkah-langkah.`
- `Tentukan turunan f(x) = 3x^2 + 2x - 5.`
- Unggah foto soal yang terbaca jelas lalu tanyakan cara menyelesaikannya.
- Unggah PDF materi dan minta chatbot menjelaskan bagian tertentu.

## 5. Unggah ke GitHub

1. Buat repository baru bernama `mathmate-ai` di https://github.com/new.
2. Pastikan jangan mengunggah API key, `.env`, atau `.streamlit/secrets.toml`.
3. Upload file proyek: `app.py`, `requirements.txt`, `README.md`, dan `.gitignore`.
4. Salin URL repository GitHub untuk formulir proyek.

Jika menggunakan Git dari terminal:

```bash
git init
git add app.py requirements.txt README.md .gitignore
git commit -m "Create MathMate AI chatbot"
git branch -M main
git remote add origin https://github.com/USERNAME/mathmate-ai.git
git push -u origin main
```

Ganti `USERNAME` dengan username GitHub kamu.

## Catatan

- Kode memakai model `gemini-2.5-flash` sebagai nilai awal. Jika model tersebut tidak tersedia pada akun/API kamu, atur environment variable `GEMINI_MODEL` ke model Gemini yang tersedia di Google AI Studio.
- Penggunaan Gemini API tunduk pada ketersediaan model, kuota, dan ketentuan akun.
- PDF dan gambar dikirim ke layanan Gemini untuk dianalisis. Jangan unggah dokumen pribadi atau sensitif.
- AI bisa salah dalam membaca simbol atau menghitung. Periksa kembali langkah dan hasilnya.
