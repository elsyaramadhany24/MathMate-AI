import os
import streamlit as st
from google import genai
from google.genai import types

# MathMate AI — Gemini + Streamlit
# API key can be set in .streamlit/secrets.toml or the GEMINI_API_KEY environment variable.

st.set_page_config(
    page_title="MathMate AI",
    page_icon="➗",
    layout="centered",
)

MODEL = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
SYSTEM_INSTRUCTION = """
Kamu adalah MathMate AI, asisten pembelajaran matematika berbahasa Indonesia.
Bantu pengguna memahami berbagai materi matematika: aritmetika, aljabar,
fungsi, trigonometri, kalkulus, matriks, aljabar linear, statistika, peluang,
matematika diskrit, dan optimasi.

Untuk soal hitungan:
1. Tulis bagian Diketahui dan Ditanyakan jika relevan.
2. Jelaskan konsep atau rumus yang digunakan.
3. Kerjakan langkah demi langkah dan tampilkan perhitungan dengan rapi.
4. Berikan jawaban akhir dan lakukan pemeriksaan singkat jika memungkinkan.
5. Jika soal pada gambar/PDF kurang jelas, sebutkan bagian yang tidak terbaca
   dan minta pengguna mengirim gambar yang lebih jelas.
6. Jangan mengarang informasi. Jika tidak yakin, jelaskan keterbatasannya.
7. Gunakan bahasa Indonesia yang jelas dan ramah. Jangan hanya memberikan
   jawaban akhir tanpa pembahasan, kecuali pengguna memintanya.
"""

def get_api_key():
    key = os.getenv("GEMINI_API_KEY", "").strip()
    if key:
        return key
    try:
        return str(st.secrets["GEMINI_API_KEY"]).strip()
    except Exception:
        return ""

def make_client():
    api_key = get_api_key()
    if not api_key:
        return None
    return genai.Client(api_key=api_key)

def uploaded_part(uploaded_file):
    data = uploaded_file.getvalue()
    mime_type = uploaded_file.type or "application/octet-stream"
    return types.Part.from_bytes(data=data, mime_type=mime_type)

st.markdown(
    """
    <div class="hero">
      <div class="hero-icon">∑</div>
      <div>
        <div class="hero-title">MathMate AI</div>
        <div class="hero-subtitle">Asisten belajar matematika berbasis Gemini</div>
      </div>
    </div>
    """,
    unsafe_allow_html=True,
)
st.write("Tanyakan soal matematika, atau unggah gambar/PDF untuk dibahas langkah demi langkah.")

with st.sidebar:
    st.header("Tentang MathMate AI")
    st.write("Asisten belajar untuk berbagai materi matematika.")
    st.markdown("**Materi yang bisa ditanyakan**")
    st.write("Aljabar · Kalkulus · Matriks · Statistika · Peluang · Optimasi · dan lainnya")
    st.caption(f"Model: {MODEL}")
    if st.button("Hapus percakapan", use_container_width=True):
        st.session_state.messages = []
        st.rerun()

if "messages" not in st.session_state:
    st.session_state.messages = []

for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])

with st.container(border=True):
    st.markdown("**Ajukan pertanyaan matematika**")
    with st.form("mathmate_form", clear_on_submit=True):
        question = st.text_area(
            "Pertanyaan",
            placeholder="Contoh: Tentukan turunan f(x) = 3x² + 2x − 5 dan jelaskan langkahnya.",
            height=100,
            label_visibility="collapsed",
        )
        uploaded = st.file_uploader(
            "Opsional: unggah soal atau materi (gambar/PDF)",
            type=["png", "jpg", "jpeg", "webp", "heic", "heif", "pdf"],
            accept_multiple_files=False,
            help="Format: PNG, JPG, WEBP, HEIC, atau PDF. Maksimal 15 MB.",
        )
        submitted = st.form_submit_button("Kirim pertanyaan", type="primary", use_container_width=True)

if submitted:
    if not question.strip() and uploaded is None:
        st.warning("Ketik pertanyaan atau unggah gambar/PDF terlebih dahulu.")
    elif uploaded is not None and uploaded.size > 15 * 1024 * 1024:
        st.error("Ukuran berkas melebihi 15 MB. Silakan unggah berkas yang lebih kecil.")
    else:
        prompt_text = question.strip() or "Tolong baca dan bahas soal matematika pada berkas yang saya unggah."
        display_text = prompt_text
        if uploaded is not None:
            display_text += f"\n\n📎 Berkas: **{uploaded.name}**"
        st.session_state.messages.append({"role": "user", "content": display_text})

        client = make_client()
        if client is None:
            st.error(
                "API key Gemini belum ditemukan. Ikuti langkah pengaturan API key di README.md, "
                "lalu jalankan ulang aplikasi."
            )
        else:
            with st.chat_message("user"):
                st.markdown(display_text)
            with st.chat_message("assistant"):
                with st.spinner("MathMate AI sedang menyusun pembahasan..."):
                    try:
                        contents = []
                        # Send recent text conversation as context, excluding the just-added message.
                        previous = st.session_state.messages[:-1][-8:]
                        for item in previous:
                            role = "user" if item["role"] == "user" else "model"
                            contents.append(
                                types.Content(
                                    role=role,
                                    parts=[types.Part.from_text(text=item["content"])]
                                )
                            )
                        current_parts = [types.Part.from_text(text=prompt_text)]
                        if uploaded is not None:
                            current_parts.append(uploaded_part(uploaded))
                        contents.append(types.Content(role="user", parts=current_parts))

                        response = client.models.generate_content(
                            model=MODEL,
                            contents=contents,
                            config=types.GenerateContentConfig(
                                system_instruction=SYSTEM_INSTRUCTION,
                                temperature=0.3,
                            ),
                        )
                        answer = response.text or "Maaf, model belum menghasilkan jawaban teks. Coba ubah pertanyaan."
                        st.markdown(answer)
                        st.session_state.messages.append({"role": "assistant", "content": answer})
                    except Exception as exc:
                        st.error(
                            "Terjadi kendala saat meminta jawaban dari Gemini. "
                            "Periksa koneksi internet, API key, kuota, dan nama model. "
                            f"Detail teknis: {exc}"
                        )

st.markdown(
    "<div class='footer'>MathMate AI • Gunakan jawaban AI sebagai bantuan belajar dan periksa kembali hasil perhitungan.</div>",
    unsafe_allow_html=True,
)

st.markdown(
    """
    <style>
    .block-container {max-width: 900px; padding-top: 2rem; padding-bottom: 2rem;}
    .hero {display:flex; gap:16px; align-items:center; padding:18px 20px; border:1px solid #e4e7ec; border-radius:18px; margin-bottom:18px; background:linear-gradient(120deg,#f7f8ff,#f1fbf7);}
    .hero-icon {width:58px;height:58px;border-radius:16px;background:#263b80;color:white;display:flex;align-items:center;justify-content:center;font-size:35px;font-weight:700;}
    .hero-title {font-size:30px;font-weight:750;line-height:1.2;color:#172554;}
    .hero-subtitle {font-size:14px;color:#526078;margin-top:4px;}
    .footer {text-align:center;color:#7b8494;font-size:12px;padding-top:20px;}
    </style>
    """,
    unsafe_allow_html=True,
)
